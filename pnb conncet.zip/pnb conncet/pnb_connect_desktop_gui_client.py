"""
PNB Connect - Desktop GUI Client

Single-file PyQt5 desktop application that acts as a client for the FastAPI Tor-enabled backend
you already have. It lets you:
 - configure API base URL and API key
 - optionally route API requests through a local Tor SOCKS5 proxy
 - start a TCP "scan" (server API /api/scan)
 - run an SSH command via server (/api/ssh)
 - create and start VMs via server (/api/vm/create and /api/vm/start)

Dependencies:
 pip install pyqt5 requests pysocks

How it works:
 - It sends JSON POST requests to the API endpoints you already created in pnb_tor_api.py.
 - If "Use local Tor SOCKS5" is enabled, requests will use the proxy at 127.0.0.1:9050.
 - This is a client; privileged operations still run on the server.

Save as: pnb_connect_desktop_gui.py
Run: python pnb_connect_desktop_gui.py

"""

import sys
import json
import threading
import traceback
from PyQt5 import QtWidgets, QtCore
import requests

DEFAULT_API = "http://127.0.0.1:8000"
DEFAULT_API_KEY = "change-me"
TOR_SOCKS = "socks5h://127.0.0.1:9050"

class WorkerSignals(QtCore.QObject):
    finished = QtCore.pyqtSignal(object)
    progress = QtCore.pyqtSignal(object)
    error = QtCore.pyqtSignal(str)

class ApiThread(QtCore.QThread):
    def __init__(self, fn, *args, **kwargs):
        super().__init__()
        self.fn = fn
        self.args = args
        self.kwargs = kwargs
        self.signals = WorkerSignals()

    def run(self):
        try:
            res = self.fn(*self.args, **self.kwargs)
            self.signals.finished.emit(res)
        except Exception as e:
            tb = traceback.format_exc()
            self.signals.error.emit(str(e) + "\n" + tb)

class PNBGui(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('PNB Connect — Desktop GUI')
        self.resize(900, 600)
        self._build_ui()

    def _build_ui(self):
        layout = QtWidgets.QVBoxLayout(self)

        # CONFIG
        cfg_group = QtWidgets.QGroupBox('Server Configuration')
        cfg_layout = QtWidgets.QFormLayout()
        self.api_edit = QtWidgets.QLineEdit(DEFAULT_API)
        self.key_edit = QtWidgets.QLineEdit(DEFAULT_API_KEY)
        self.tor_check = QtWidgets.QCheckBox('Use local Tor SOCKS5 (127.0.0.1:9050)')
        cfg_layout.addRow('API base URL:', self.api_edit)
        cfg_layout.addRow('API key:', self.key_edit)
        cfg_layout.addRow(self.tor_check)
        cfg_group.setLayout(cfg_layout)
        layout.addWidget(cfg_group)

        # MAIN GRID
        grid = QtWidgets.QGridLayout()

        # Scan panel
        scan_group = QtWidgets.QGroupBox('Network Scan (server-side, TCP connect via Tor)')
        scan_layout = QtWidgets.QVBoxLayout()
        self.hosts_text = QtWidgets.QPlainTextEdit('192.168.1.10, exampleonion.onion')
        scan_btn_row = QtWidgets.QHBoxLayout()
        self.scan_btn = QtWidgets.QPushButton('Start Scan')
        self.scan_btn.clicked.connect(self.start_scan)
        self.scan_stop_btn = QtWidgets.QPushButton('Stop')
        self.scan_stop_btn.clicked.connect(self.stop_scan)
        self.scan_stop_btn.setEnabled(False)
        self.scan_status = QtWidgets.QLabel('Idle')
        scan_btn_row.addWidget(self.scan_btn)
        scan_btn_row.addWidget(self.scan_stop_btn)
        scan_btn_row.addStretch()
        scan_btn_row.addWidget(self.scan_status)
        self.scan_list = QtWidgets.QListWidget()
        scan_layout.addWidget(self.hosts_text)
        scan_layout.addLayout(scan_btn_row)
        scan_layout.addWidget(self.scan_list)
        scan_group.setLayout(scan_layout)

        # SSH panel
        ssh_group = QtWidgets.QGroupBox('SSH (via server over Tor)')
        ssh_layout = QtWidgets.QFormLayout()
        self.ssh_host = QtWidgets.QLineEdit('exampleonion.onion')
        self.ssh_user = QtWidgets.QLineEdit('root')
        self.ssh_pass = QtWidgets.QLineEdit('')
        self.ssh_pass.setEchoMode(QtWidgets.QLineEdit.Password)
        self.ssh_cmd = QtWidgets.QLineEdit('uname -a')
        self.ssh_run_btn = QtWidgets.QPushButton('Run SSH Command')
        self.ssh_run_btn.clicked.connect(self.run_ssh)
        self.ssh_out = QtWidgets.QPlainTextEdit()
        self.ssh_out.setReadOnly(True)
        ssh_layout.addRow('Host:', self.ssh_host)
        ssh_layout.addRow('User:', self.ssh_user)
        ssh_layout.addRow('Password:', self.ssh_pass)
        ssh_layout.addRow('Command:', self.ssh_cmd)
        ssh_layout.addRow(self.ssh_run_btn)
        ssh_layout.addRow(self.ssh_out)
        ssh_group.setLayout(ssh_layout)

        # VM panel
        vm_group = QtWidgets.QGroupBox('Virtual Machine (server-side)')
        vm_layout = QtWidgets.QFormLayout()
        self.vm_name = QtWidgets.QLineEdit('pnb_demo_vm')
        self.vm_iso = QtWidgets.QLineEdit('')
        self.vm_ram = QtWidgets.QSpinBox(); self.vm_ram.setRange(128, 32768); self.vm_ram.setValue(1024)
        self.vm_create_btn = QtWidgets.QPushButton('Create VM')
        self.vm_create_btn.clicked.connect(self.create_vm)
        self.vm_start_btn = QtWidgets.QPushButton('Start VM')
        self.vm_start_btn.clicked.connect(self.start_vm)
        self.vm_list = QtWidgets.QListWidget()
        vm_layout.addRow('Name:', self.vm_name)
        vm_layout.addRow('ISO (url or server local path):', self.vm_iso)
        vm_layout.addRow('RAM (MB):', self.vm_ram)
        vm_layout.addRow(self.vm_create_btn, self.vm_start_btn)
        vm_layout.addRow('Known VMs (locally created):', self.vm_list)
        vm_group.setLayout(vm_layout)

        # Layout placement
        grid.addWidget(scan_group, 0, 0)
        grid.addWidget(ssh_group, 0, 1)
        grid.addWidget(vm_group, 1, 0, 1, 2)

        layout.addLayout(grid)

        # Status bar
        self.status = QtWidgets.QLabel('Ready')
        layout.addWidget(self.status)

        # State
        self._scan_thread = None
        self._active = True

    def _session(self):
        s = requests.Session()
        s.headers.update({ 'x-api-key': self.key_edit.text().strip(), 'Content-Type': 'application/json' })
        if self.tor_check.isChecked():
            s.proxies = { 'http': TOR_SOCKS, 'https': TOR_SOCKS }
        return s

    # ---- scan ----
    def start_scan(self):
        raw = self.hosts_text.toPlainText().strip()
        if not raw:
            QtWidgets.QMessageBox.warning(self, 'No hosts', 'Enter hosts to scan')
            return
        hosts = [h.strip() for h in raw.replace('\n',',').split(',') if h.strip()]
        self.scan_list.clear()
        self.scan_btn.setEnabled(False)
        self.scan_stop_btn.setEnabled(True)
        self.scan_status.setText('Scanning...')
        self._scan_thread = ApiThread(self._do_scan, hosts)
        self._scan_thread.signals.finished.connect(self.on_scan_finished)
        self._scan_thread.signals.error.connect(self.on_error)
        self._scan_thread.start()

    def stop_scan(self):
        # Not possible to cancel a requests call cleanly; we simply set a flag and let it finish
        self._active = False
        self.scan_status.setText('Cancelling...')

    def _do_scan(self, hosts):
        s = self._session()
        payload = { 'hosts': hosts, 'port': 22, 'timeout': 6.0 }
        resp = s.post(self.api_edit.text().rstrip('/') + '/api/scan', json=payload, timeout=30)
        resp.raise_for_status()
        return resp.json()

    def on_scan_finished(self, res):
        try:
            results = res.get('results', {})
            for h,r in results.items():
                item = f"{h} — {'open' if r.get('tcp_open') else 'closed'} (port {r.get('port')})"
                self.scan_list.addItem(item)
            self.scan_status.setText('Finished')
        except Exception as e:
            self.on_error(str(e))
        finally:
            self.scan_btn.setEnabled(True)
            self.scan_stop_btn.setEnabled(False)
            self._active = True

    # ---- ssh ----
    def run_ssh(self):
        host = self.ssh_host.text().strip()
        if not host:
            QtWidgets.QMessageBox.warning(self, 'Missing host', 'Enter SSH host')
            return
        payload = {
            'host': host,
            'port': 22,
            'username': self.ssh_user.text().strip() or None,
            'password': self.ssh_pass.text() or None,
            'command': self.ssh_cmd.text().strip() or 'uname -a',
            'timeout': 20.0
        }
        self.ssh_run_btn.setEnabled(False)
        self.ssh_out.setPlainText('Calling API...')
        t = ApiThread(self._do_ssh, payload)
        t.signals.finished.connect(self.on_ssh_finished)
        t.signals.error.connect(self.on_error)
        t.start()

    def _do_ssh(self, payload):
        s = self._session()
        resp = s.post(self.api_edit.text().rstrip('/') + '/api/ssh', json=payload, timeout=60)
        resp.raise_for_status()
        return resp.json()

    def on_ssh_finished(self, res):
        self.ssh_run_btn.setEnabled(True)
        if res.get('ok'):
            out = res.get('out')
            self.ssh_out.setPlainText(json.dumps(out, indent=2))
            self.status.setText('SSH done')
        else:
            self.ssh_out.setPlainText(json.dumps(res, indent=2))
            self.status.setText('SSH returned error')

    # ---- VM ----
    def create_vm(self):
        vm_name = self.vm_name.text().strip() or f'pnb_vm_{int(QtCore.QDateTime.currentMSecsSinceEpoch()%10000)}'
        payload = {
            'vm_name': vm_name,
            'iso_url': self.vm_iso.text().strip() or None,
            'ram_mb': int(self.vm_ram.value()),
            'disk_mb': 10240
        }
        self.vm_create_btn.setEnabled(False)
        t = ApiThread(self._do_vm_create, payload)
        t.signals.finished.connect(self.on_vm_create_finished)
        t.signals.error.connect(self.on_error)
        t.start()

    def _do_vm_create(self, payload):
        s = self._session()
        resp = s.post(self.api_edit.text().rstrip('/') + '/api/vm/create', json=payload, timeout=120)
        resp.raise_for_status()
        return resp.json()

    def on_vm_create_finished(self, res):
        self.vm_create_btn.setEnabled(True)
        if res.get('ok'):
            name = self.vm_name.text().strip()
            self.vm_list.addItem(name)
            self.status.setText('VM created')
            QtWidgets.QMessageBox.information(self, 'VM Created', f"{name} created on server")
        else:
            QtWidgets.QMessageBox.critical(self, 'VM Error', json.dumps(res))

    def start_vm(self):
        if self.vm_list.count() > 0:
            vm_name = self.vm_list.item(self.vm_list.count()-1).text()
        else:
            vm_name = self.vm_name.text().strip()
        if not vm_name:
            QtWidgets.QMessageBox.warning(self, 'No VM specified', 'Create or enter a VM name first')
            return
        self.vm_start_btn.setEnabled(False)
        t = ApiThread(self._do_vm_start, vm_name)
        t.signals.finished.connect(self.on_vm_start_finished)
        t.signals.error.connect(self.on_error)
        t.start()

    def _do_vm_start(self, vm_name):
        s = self._session()
        # start expects vm_name as query param in the server implementation; send POST anyway
        resp = s.post(self.api_edit.text().rstrip('/') + f'/api/vm/start?vm_name={vm_name}', json={}, timeout=60)
        resp.raise_for_status()
        return resp.json()

    def on_vm_start_finished(self, res):
        self.vm_start_btn.setEnabled(True)
        if res.get('ok'):
            QtWidgets.QMessageBox.information(self, 'VM Started', 'VM has been started on the server')
            self.status.setText('VM started')
        else:
            QtWidgets.QMessageBox.critical(self, 'VM start error', json.dumps(res))

    def on_error(self, err):
        # Show a dialog and log
        QtWidgets.QMessageBox.critical(self, 'API Error', str(err))
        self.status.setText('Error')
        self.scan_btn.setEnabled(True)
        self.scan_stop_btn.setEnabled(False)
        self.ssh_run_btn.setEnabled(True)
        self.vm_create_btn.setEnabled(True)
        self.vm_start_btn.setEnabled(True)


def main():
    app = QtWidgets.QApplication(sys.argv)
    gui = PNBGui()
    gui.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
