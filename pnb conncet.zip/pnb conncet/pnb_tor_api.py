# pnb_tor_api.py
# FastAPI backend that routes certain actions through Tor (SOCKS5) and can be exposed as a hidden service.
# WARNING: This is a prototype. Harden authentication and validation before production use.

import os
import subprocess
import json
import time
from typing import Optional, List

from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import requests
import socks
import socket
import paramiko

# Optional: stem for creating onion hidden service
try:
    from stem.control import Controller
    STEM_AVAILABLE = True
except Exception:
    STEM_AVAILABLE = False

# Load API key from env
API_KEY = os.environ.get("PNB_API_KEY", "change-me")
TOR_SOCKS_HOST = os.environ.get("TOR_SOCKS_HOST", "127.0.0.1")
TOR_SOCKS_PORT = int(os.environ.get("TOR_SOCKS_PORT", 9050))
TOR_CONTROL_PORT = int(os.environ.get("TOR_CONTROL_PORT", 9051))

def require_api_key(request: Request):
    key = request.headers.get("x-api-key")
    if key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key")

app = FastAPI(title="PNB Connect (Tor-enabled prototype)")

# ---- Models ----
class ScanRequest(BaseModel):
    hosts: List[str]                 # list of hostnames/IPs (or onion addresses) to check
    port: int = 22                   # TCP port to test (Tor supports TCP only)
    timeout: float = 5.0

class SSHRequest(BaseModel):
    host: str
    port: int = 22
    username: Optional[str] = None
    password: Optional[str] = None
    command: str = "uname -a"
    timeout: float = 15.0

class VMCreateRequest(BaseModel):
    vm_name: str
    iso_url: Optional[str] = None
    ram_mb: int = 1024
    disk_mb: int = 10240

# ---- Utility: run subprocess helper ----
def run_cmd(cmd, check=False):
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False)
    out, err = p.communicate()
    rc = p.returncode
    return rc, (out.decode(errors="ignore") if out else ""), (err.decode(errors="ignore") if err else "")

# ---- Tor-aware TCP connect (using SOCKS5 via requests/pySocks) ----
def tcp_connect_via_tor(host: str, port: int, timeout: float = 5.0) -> bool:
    """
    Attempt a TCP connect to (host,port) over Tor SOCKS5 proxy.
    For .onion addresses you must have Tor running locally (it will resolve them).
    Returns True on successful connect.
    """
    # Use socks.socksocket to create a proxied socket
    sock = socks.socksocket()
    sock.set_proxy(socks.SOCKS5, TOR_SOCKS_HOST, TOR_SOCKS_PORT)
    sock.settimeout(timeout)
    try:
        sock.connect((host, port))
        sock.close()
        return True
    except Exception as e:
        return False

# ---- SSH over Tor using Paramiko + socks socket ----
def ssh_run_via_tor(host: str, port: int = 22, username: Optional[str] = None, password: Optional[str] = None, command: str = "uname -a", timeout: int = 15):
    """
    Make an SSH connection to host:port via Tor SOCKS5 by creating a socksocket and
    building a Paramiko transport over it.
    Note: Paramiko won't do DNS through the socks socket automatically; using the socks socket
    connect((host,port)) will let Tor resolve .onion names.
    """
    ss = socks.socksocket()
    ss.set_proxy(socks.SOCKS5, TOR_SOCKS_HOST, TOR_SOCKS_PORT)
    ss.settimeout(timeout)
    try:
        ss.connect((host, port))
    except Exception as e:
        return False, f"Connect failed: {e}"

    try:
        t = paramiko.Transport(ss)
        t.start_client(timeout=timeout)
        if username is None:
            username = "root"
        # Try password auth if provided, otherwise attempt no auth (may fail)
        if password:
            t.auth_password(username, password, timeout=timeout)
        else:
            # try empty-password or key auth fallback (not implemented here)
            pass

        chan = t.open_session()
        chan.exec_command(command)
        stdout = chan.makefile("r", -1).read()
        stderr = chan.makefile_stderr("r", -1).read()
        chan.close()
        t.close()
        return True, {"stdout": stdout, "stderr": stderr}
    except Exception as e:
        try:
            t.close()
        except Exception:
            pass
        return False, str(e)

# ---- Endpoints ----

@app.post("/api/scan", dependencies=[Depends(require_api_key)])
def api_scan(req: ScanRequest):
    """
    Perform TCP connect checks for a list of hosts over Tor.
    NOTE: ICMP ping is not available over Tor.
    """
    results = {}
    for h in req.hosts:
        ok = tcp_connect_via_tor(h, req.port, timeout=req.timeout)
        results[h] = {"port": req.port, "tcp_open": ok}
    return {"ok": True, "results": results}

@app.post("/api/ssh", dependencies=[Depends(require_api_key)])
def api_ssh(req: SSHRequest):
    ok, res = ssh_run_via_tor(req.host, port=req.port, username=req.username, password=req.password, command=req.command, timeout=int(req.timeout))
    if ok:
        return {"ok": True, "out": res}
    else:
        raise HTTPException(status_code=500, detail={"error": res})

@app.post("/api/vm/create", dependencies=[Depends(require_api_key)])
def api_vm_create(req: VMCreateRequest):
    """
    Create a VirtualBox VM locally. This endpoint **runs VBoxManage on the server**.
    Very sensitive — ensure API access control.
    """
    vm_name = req.vm_name
    base_folder = os.path.expanduser("~/PNB_VMs")
    # Minimal safe sanitization
    vm_name = "".join([c for c in vm_name if c.isalnum() or c in ("-", "_")]).strip() or f"pnb_vm_{int(time.time())}"
    # createvm
    rc, out, err = run_cmd(["VBoxManage", "createvm", "--name", vm_name, "--register", "--basefolder", base_folder])
    if rc != 0:
        return JSONResponse(status_code=500, content={"ok": False, "error": "createvm failed", "details": err or out})
    # modifyvm
    rc, out, err = run_cmd(["VBoxManage", "modifyvm", vm_name, "--memory", str(req.ram_mb)])
    if rc != 0:
        return JSONResponse(status_code=500, content={"ok": False, "error": "modifyvm failed", "details": err or out})
    # createhd
    disk_path = os.path.join(base_folder, vm_name, f"{vm_name}.vdi")
    rc, out, err = run_cmd(["VBoxManage", "createhd", "--filename", disk_path, "--size", str(req.disk_mb)])
    if rc != 0:
        return JSONResponse(status_code=500, content={"ok": False, "error": "createhd failed", "details": err or out})
    # storagectl + attach
    run_cmd(["VBoxManage", "storagectl", vm_name, "--name", "SATA Controller", "--add", "sata", "--controller", "IntelAhci"])
    run_cmd(["VBoxManage", "storageattach", vm_name, "--storagectl", "SATA Controller", "--port", "0", "--device", "0", "--type", "hdd", "--medium", disk_path])
    # attach ISO if provided (download & attach) — here we only attach if iso_url is local path or already available
    return {"ok": True, "message": f"VM {vm_name} created (base folder {base_folder})."}

@app.post("/api/vm/start", dependencies=[Depends(require_api_key)])
def api_vm_start(vm_name: str):
    rc, out, err = run_cmd(["VBoxManage", "startvm", vm_name, "--type", "gui"])
    if rc != 0:
        return JSONResponse(status_code=500, content={"ok": False, "error": "startvm failed", "details": err or out})
    return {"ok": True, "message": f"VM {vm_name} started"}

# ---- Optional: create ephemeral hidden service (onion v3) ----
@app.post("/api/hidden_service/create", dependencies=[Depends(require_api_key)])
def create_hidden_service(local_port: int = 8000):
    if not STEM_AVAILABLE:
        raise HTTPException(status_code=500, detail="stem is not installed on server")
    try:
        # try to connect to Tor control port using cookie or password
        with Controller.from_port(port=TOR_CONTROL_PORT) as controller:
            controller.authenticate()  # assuming cookie auth or configured password
            response = controller.create_ephemeral_hidden_service({80: local_port}, await_publication=True)
            onion = response.service_id + ".onion"
            return {"ok": True, "onion": onion}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Root
@app.get("/")
def root():
    return {"ok": True, "msg": "PNB Connect Tor-enabled API (prototype)."}

