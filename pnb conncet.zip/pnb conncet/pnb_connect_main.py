"""
PNB Connect
A simple prototype GUI application that can:
 - scan the local network for reachable hosts (ping sweep)
 - connect to a host via SSH (using paramiko) to run commands
 - create and start a VirtualBox VM locally using VBoxManage (which pops up a VM window)

NOTES / REQUIREMENTS:
 - Python 3.8+
 - Install dependencies: pip install pyqt5 paramiko
 - VirtualBox must be installed and `VBoxManage` must be in your PATH (or modify VBOXMANAGE variable below)
 - This is a prototype. Running VM creation commands will create VMs on your machine — use carefully.
 - On Windows, run with Administrator privileges for some VBoxManage actions.

How to run:
 1. Install requirements.
 2. Adjust configuration variables below (like default VM settings).
 3. python PNB_Connect_main.py

This single-file project is meant as a starting point — you can expand it to support remote VM creation, better error handling, templates, and integration with cloud hypervisors.

"""

import sys
import os
import platform
import subprocess
import threading
import time
import socket
from pathlib import Path

from PyQt5 import QtWidgets, QtCore, QtGui

try:
    import paramiko
except Exception:
    paramiko = None

# ---------- Configuration ----------
VBOXMANAGE = "VBoxManage"  # or full path to VBoxManage binary
DEFAULT_VM_BASE_DIR = str(Path.home() / "PNB_VMs")
DEFAULT_VM_RAM = 1024  # MB
DEFAULT_VM_VRAM = 8    # MB
DEFAULT_VM_CPUS = 1
DEFAULT_DISK_SIZE_MB = 10240  # 10GB
PING_TIMEOUT = 0.5

# ---------- Utilities ----------

def run_subprocess(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False):
    """Run subprocess and return (returncode, stdout, stderr)"""
    try:
        p = subprocess.Popen(cmd, stdout=stdout, stderr=stderr, shell=False)
        out, err = p.communicate()
        return p.returncode, (out.decode(errors='ignore') if out else ''), (err.decode(errors='ignore') if err else '')
    except FileNotFoundError as e:
        return 127, '', str(e)


def is_tool_available(name):
    return run_subprocess([name, "--version"])[0] == 0


# ---------- Network scanning (simple ping sweep) ----------

def ip_range_from_cidr(cidr):
    # very small helper for /24 only — for prototype simplicity
    import ipaddress
    net = ipaddress.ip_network(cidr, strict=False)
    return [str(ip) for ip in net.hosts()]


def ping_host(host):
    # cross-platform ping
    param = '-n' if platform.system().lower() == 'windows' else '-c'
    timeout_param = '-w' if platform.system().lower() == 'windows' else '-W'
    cmd = ['ping', param, '1', timeout_param, str(int(PING_TIMEOUT*1000)) if platform.system().lower()=='windows' else str(int(PING_TIMEOUT)), host]
    rc, out, err = run_subprocess(cmd)
    return rc == 0


def simple_ping_sweep(cidr_or_hosts, progress_callback=None):
    """If cidr_or_hosts looks like '192.168.1.0/24' use range. Otherwise accepts list of hosts."""
    hosts = []
    if isinstance(cidr_or_hosts, str) and '/' in cidr_or_hosts:
        hosts = ip_range_from_cidr(cidr_or_hosts)
    elif isinstance(cidr_or_hosts, (list, tuple)):
        hosts = cidr_or_hosts
    else:
        hosts = [cidr_or_hosts]

    alive = []
    total = len(hosts)
    for i, h in enumerate(hosts, start=1):
        ok = ping_host(h)
        if ok:
            alive.append(h)
        if progress_callback:
            progress_callback(i, total, h, ok)
    return alive


# ---------- VirtualBox VM helpers ----------

def ensure_dir(p):
    Path(p).mkdir(parents=True, exist_ok=True)


def sanitize_vm_name(name):
    return ''.join(c for c in name if c.isalnum() or c in ('-', '_')).strip()


def create_virtualbox_vm(vm_name, iso_path=None, base_dir=DEFAULT_VM_BASE_DIR, ram_mb=DEFAULT_VM_RAM, vram_mb=DEFAULT_VM_VRAM, cpus=DEFAULT_VM_CPUS, disk_mb=DEFAULT_DISK_SIZE_MB, gui=True):
    """Create a VM using VBoxManage. This is a simple default workflow.
    It will:
     - createvm
     - modifyvm (memory, cpus, vram)
     - createhd
     - storagectl + attach
     - optionally attach an ISO as IDE controller
    """
    vm_name = sanitize_vm_name(vm_name)
    ensure_dir(base_dir)
    vm_path = os.path.join(base_dir, vm_name)
    ensure_dir(vm_path)

    # create vm
    rc, out, err = run_subprocess([VBOXMANAGE, 'createvm', '--name', vm_name, '--register', '--basefolder', base_dir])
    if rc != 0:
        return False, f'createvm failed: {err or out}'

    # settings
    rc, out, err = run_subprocess([VBOXMANAGE, 'modifyvm', vm_name, '--memory', str(ram_mb), '--vram', str(vram_mb), '--cpus', str(cpus)])
    if rc != 0:
        return False, f'modifyvm failed: {err or out}'

    # create disk
    disk_path = os.path.join(vm_path, f'{vm_name}.vdi')
    rc, out, err = run_subprocess([VBOXMANAGE, 'createhd', '--filename', disk_path, '--size', str(disk_mb)])
    if rc != 0:
        return False, f'createhd failed: {err or out}'

    # attach storage controller
    rc, out, err = run_subprocess([VBOXMANAGE, 'storagectl', vm_name, '--name', 'SATA Controller', '--add', 'sata', '--controller', 'IntelAhci'])
    if rc != 0:
        return False, f'storagectl failed: {err or out}'

    rc, out, err = run_subprocess([VBOXMANAGE, 'storageattach', vm_name, '--storagectl', 'SATA Controller', '--port', '0', '--device', '0', '--type', 'hdd', '--medium', disk_path])
    if rc != 0:
        return False, f'storageattach hdd failed: {err or out}'

    if iso_path:
        rc, out, err = run_subprocess([VBOXMANAGE, 'storagectl', vm_name, '--name', 'IDE Controller', '--add', 'ide'])
        # safe to continue even if controller exists
        rc, out, err = run_subprocess([VBOXMANAGE, 'storageattach', vm_name, '--storagectl', 'IDE Controller', '--port', '0', '--device', '0', '--type', 'dvddrive', '--medium', iso_path])
        if rc != 0:
            return False, f'storageattach iso failed: {err or out}'

    return True, f'VM {vm_name} created successfully at {vm_path}.vdi'


def start_virtualbox_vm(vm_name, gui=True):
    args = [VBOXMANAGE, 'startvm', vm_name]
    if not gui:
        args += ['--type', 'headless']
    rc, out, err = run_subprocess(args)
    if rc != 0:
        return False, f'startvm failed: {err or out}'
    return True, f'VM {vm_name} started'


# ---------- SSH helpers ----------

def ssh_run_command(host, port=22, username=None, password=None, command='uname -a', timeout=10):
    if paramiko is None:
        return False, 'paramiko not installed'
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname=host, port=port, username=username, password=password, timeout=timeout)
        stdin, stdout, stderr = client.exec_command(command)
        out = stdout.read().decode(errors='ignore')
        err = stderr.read().decode(errors='ignore')
        client.close()
        return True, (out, err)
    except Exception as e:
        return False, str(e)


# ---------- PyQt5 GUI ----------

class WorkerSignals(QtCore.QObject):
    progress = QtCore.pyqtSignal(int, int, str, bool)
    finished = QtCore.pyqtSignal(object)
    message = QtCore.pyqtSignal(str)


class PingSweepThread(QtCore.QThread):
    def __init__(self, cidr_or_hosts):
        super().__init__()
        self.cidr_or_hosts = cidr_or_hosts
        self.signals = WorkerSignals()

    def run(self):
        def cb(i, total, host, ok):
            self.signals.progress.emit(i, total, host, ok)
        res = simple_ping_sweep(self.cidr_or_hosts, progress_callback=cb)
        self.signals.finished.emit(res)


class PNBConnectApp(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('PNB Connect')
        self.setGeometry(200, 200, 800, 500)
        self._build_ui()

    def _build_ui(self):
        layout = QtWidgets.QVBoxLayout(self)

        header = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel('<h2>PNB Connect</h2>')
        header.addWidget(title)
        header.addStretch()
        layout.addLayout(header)

        # Network scan section
        scan_box = QtWidgets.QGroupBox('Network Scan')
        scan_layout = QtWidgets.QVBoxLayout()
        input_row = QtWidgets.QHBoxLayout()
        self.cidr_input = QtWidgets.QLineEdit('192.168.1.0/24')
        self.scan_btn = QtWidgets.QPushButton('Scan')
        self.scan_btn.clicked.connect(self.start_scan)
        input_row.addWidget(self.cidr_input)
        input_row.addWidget(self.scan_btn)
        scan_layout.addLayout(input_row)
        self.scan_progress = QtWidgets.QProgressBar()
        scan_layout.addWidget(self.scan_progress)
        self.scan_output = QtWidgets.QListWidget()
        scan_layout.addWidget(self.scan_output)
        scan_box.setLayout(scan_layout)
        layout.addWidget(scan_box)

        # VM section
        vm_box = QtWidgets.QGroupBox('Virtual Machine')
        vm_layout = QtWidgets.QFormLayout()
        self.vm_name_input = QtWidgets.QLineEdit('pnb_test_vm')
        self.iso_path_input = QtWidgets.QLineEdit('')
        self.browse_iso_btn = QtWidgets.QPushButton('Browse...')
        self.browse_iso_btn.clicked.connect(self.browse_iso)
        iso_row = QtWidgets.QHBoxLayout()
        iso_row.addWidget(self.iso_path_input)
        iso_row.addWidget(self.browse_iso_btn)

        self.create_vm_btn = QtWidgets.QPushButton('Create VM (VBoxManage)')
        self.create_vm_btn.clicked.connect(self.create_vm)
        self.start_vm_btn = QtWidgets.QPushButton('Start VM')
        self.start_vm_btn.clicked.connect(self.start_vm)

        vm_layout.addRow('Name:', self.vm_name_input)
        vm_layout.addRow('ISO (optional):', iso_row)
        vm_layout.addRow(self.create_vm_btn, self.start_vm_btn)
        vm_box.setLayout(vm_layout)
        layout.addWidget(vm_box)

        # SSH section
        ssh_box = QtWidgets.QGroupBox('SSH Connect')
        ssh_layout = QtWidgets.QFormLayout()
        self.ssh_host = QtWidgets.QLineEdit('')
        self.ssh_user = QtWidgets.QLineEdit('root')
        self.ssh_pass = QtWidgets.QLineEdit('')
        self.ssh_pass.setEchoMode(QtWidgets.QLineEdit.Password)
        self.ssh_run_btn = QtWidgets.QPushButton('Run uname -a')
        self.ssh_run_btn.clicked.connect(self.ssh_run)
        self.ssh_output = QtWidgets.QTextEdit()
        self.ssh_output.setReadOnly(True)
        ssh_layout.addRow('Host:', self.ssh_host)
        ssh_layout.addRow('User:', self.ssh_user)
        ssh_layout.addRow('Password:', self.ssh_pass)
        ssh_layout.addRow(self.ssh_run_btn)
        ssh_layout.addRow(self.ssh_output)
        ssh_box.setLayout(ssh_layout)
        layout.addWidget(ssh_box)

        # Status bar
        self.status = QtWidgets.QLabel('Ready')
        layout.addWidget(self.status)

    # ---------- UI actions ----------
    def start_scan(self):
        cidr = self.cidr_input.text().strip()
        self.scan_output.clear()
        self.scan_progress.setValue(0)
        self.scan_thread = PingSweepThread(cidr)
        self.scan_thread.signals.progress.connect(self.on_scan_progress)
        self.scan_thread.signals.finished.connect(self.on_scan_finished)
        self.scan_thread.start()
        self.status.setText('Scanning...')

    def on_scan_progress(self, i, total, host, ok):
        self.scan_progress.setMaximum(total)
        self.scan_progress.setValue(i)
        if ok:
            self.scan_output.addItem(f'{host} ✓')
        else:
            # optionally add unreachable hosts
            pass

    def on_scan_finished(self, res):
        self.status.setText(f'Scan finished: {len(res)} hosts alive')

    def browse_iso(self):
        fn, _ = QtWidgets.QFileDialog.getOpenFileName(self, 'Select ISO', str(Path.home()), 'ISO Files (*.iso);;All Files (*)')
        if fn:
            self.iso_path_input.setText(fn)

    def create_vm(self):
        vm_name = self.vm_name_input.text().strip()
        iso = self.iso_path_input.text().strip() or None
        if not vm_name:
            QtWidgets.QMessageBox.warning(self, 'Missing name', 'Please enter a VM name')
            return
        self.status.setText('Creating VM...')
        def task():
            ok, msg = create_virtualbox_vm(vm_name, iso_path=iso)
            QtCore.QMetaObject.invokeMethod(self, 'on_vm_create_finished', QtCore.Qt.QueuedConnection, QtCore.Q_ARG(bool, ok), QtCore.Q_ARG(str, msg))
        threading.Thread(target=task, daemon=True).start()

    @QtCore.pyqtSlot(bool, str)
    def on_vm_create_finished(self, ok, msg):
        if ok:
            QtWidgets.QMessageBox.information(self, 'VM Created', msg)
            self.status.setText('VM created')
        else:
            QtWidgets.QMessageBox.critical(self, 'VM Error', msg)
            self.status.setText('VM creation failed')

    def start_vm(self):
        vm_name = self.vm_name_input.text().strip()
        if not vm_name:
            QtWidgets.QMessageBox.warning(self, 'Missing name', 'Enter VM name first')
            return
        self.status.setText('Starting VM...')
        def task():
            ok, msg = start_virtualbox_vm(vm_name, gui=True)
            QtCore.QMetaObject.invokeMethod(self, 'on_vm_start_finished', QtCore.Qt.QueuedConnection, QtCore.Q_ARG(bool, ok), QtCore.Q_ARG(str, msg))
        threading.Thread(target=task, daemon=True).start()

    @QtCore.pyqtSlot(bool, str)
    def on_vm_start_finished(self, ok, msg):
        if ok:
            QtWidgets.QMessageBox.information(self, 'VM Started', msg)
            self.status.setText('VM started')
        else:
            QtWidgets.QMessageBox.critical(self, 'VM Error', msg)
            self.status.setText('VM start failed')

    def ssh_run(self):
        host = self.ssh_host.text().strip()
        user = self.ssh_user.text().strip() or None
        pw = self.ssh_pass.text() or None
        if not host:
            QtWidgets.QMessageBox.warning(self, 'Missing host', 'Enter SSH host')
            return
        self.status.setText('Running SSH command...')
        def task():
            ok, res = ssh_run_command(host, username=user, password=pw, command='uname -a')
            if ok:
                out, err = res
                txt = f'OUT:\n{out}\nERR:\n{err}'
            else:
                txt = f'Error: {res}'
            QtCore.QMetaObject.invokeMethod(self, 'on_ssh_finished', QtCore.Qt.QueuedConnection, QtCore.Q_ARG(str, txt))
        threading.Thread(target=task, daemon=True).start()

    @QtCore.pyqtSlot(str)
    def on_ssh_finished(self, txt):
        self.ssh_output.setPlainText(txt)
        self.status.setText('SSH command finished')


# ---------- Main ----------

def main():
    app = QtWidgets.QApplication(sys.argv)
    # Quick checks
    if run_subprocess([VBOXMANAGE, '--version'])[0] != 0:
        print('Warning: VBoxManage not found or not working. VM features will fail unless VirtualBox and VBoxManage are installed and in PATH.')
    if paramiko is None:
        print('Notice: paramiko not installed. SSH features will be disabled. pip install paramiko')

    widget = PNBConnectApp()
    widget.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
